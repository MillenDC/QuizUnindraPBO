package v4;

public class Obat {
  private String namaObat;
  private int biayaObat;

  public void Perawatan(String namaObat, int biayaObat) {
    this.namaObat = namaObat;
    this.biayaObat = biayaObat;
  }

  public String getNamaDokter() {
    return namaObat;
  }

  public int getBiayaDokter() {
    return biayaObat;
  }
}