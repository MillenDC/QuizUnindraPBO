package v4;

import java.util.ArrayList;
import java.util.Scanner;

public class Receipt {
  public static void main(String[] args) {
    Scanner inputan = new Scanner(System.in);

    Obat karung = new Obat();
    Dokter paperBag = new Dokter();

    String namaPasien;
    String alamtPasien;
    int noTelepon;

    String kasir = "Hambali";

    ArrayList<String> menu = new ArrayList<String>();
    menu.add("");
    menu.add("Gigi");
    menu.add("Anak");
    menu.add("Umum");

    ArrayList<String> poliGigi = new ArrayList<String>();
    poliGigi.add("");
    poliGigi.add("dr. Poli Gigi 1");
    poliGigi.add("dr. Poli Gigi 2");
    poliGigi.add("dr. Poli Gigi 3");

    ArrayList<String> poliAnak = new ArrayList<String>();
    poliAnak.add("");
    poliAnak.add("dr. Poli Anak 1");
    poliAnak.add("dr. Poli Anak 2");
    poliAnak.add("dr. Poli Anak 3");

    ArrayList<String> poliUmum = new ArrayList<String>();
    poliUmum.add("");
    poliUmum.add("dr. Poli Umum 1");
    poliUmum.add("dr. Poli Umum 1");
    poliUmum.add("dr. Poli Umum 1");

    System.out.println("--- SELAMAT DATANG DI RUMAH SAKIT WARAS ---");
    System.out.println("========================================");
    System.out.println();
    System.out.println("------------------o0o--------------------");

    System.out.println("* Masukkan Data Pasien *");
    System.out.print("Masukkan Nama: ");
    namaPasien = inputan.nextLine();
    System.out.print("Masukkan Alamat: ");
    alamtPasien = inputan.nextLine();
    System.out.print("Masukkan No. TLP: ");
    noTelepon = inputan.nextInt();
    String dummy = inputan.nextLine();
    System.out.println();

    for (int i = 1; i < menu.size(); i++) {
      System.out.println(i + ". " + menu.get(i));
    }

    System.out.println();
    System.out.print("Pilih Poli: ");
    int pilihanPoli = inputan.nextInt();

    if (pilihanPoli == 1) {
      for (int i = 1; i < poliGigi.size(); i++) {
        System.out.println(i + ". " + poliGigi.get(i));
      }

      System.out.println();
      System.out.print("Pilih Dokter: ");
      int pilihDokter = inputan.nextInt();
      System.out.print("Berikan Keterangan Dokter: ");
      String keteranganDokter = inputan.nextLine();
      String dummySatu = inputan.nextLine();

      System.out.println("");
      System.out.print("Masukkan Biaya Pendaftaran: ");
      int biayaPendaftaran = inputan.nextInt();
      System.out.print("Masukkan Biaya Obat: ");
      int biayaObat = inputan.nextInt();
      System.out.print("Masukkan Biaya Vitamin: ");
      int biayaVitamin = inputan.nextInt();
      System.out.print("Masukkan Biaya Pendaftaran: ");
      int biayaDokter = inputan.nextInt();
      System.out.println();
      System.out.println("------------------o0o--------------------");
      System.out.println("========================================");
      System.out.println("Masukkan Biaya Pendaftaran: ");
      System.out.println();

      int totalBiaya = biayaPendaftaran + biayaObat + biayaVitamin + biayaDokter;

      System.out.println("Poli: " + pilihanPoli);
      System.out.println("Dokter: " + pilihDokter);
      System.out.println("Keterangan: " + keteranganDokter);
      System.out.println("Total Biaya yang di Bayar Pasien: " + totalBiaya);

    } else if (pilihanPoli == 2) {
      for (int i = 1; i < poliAnak.size(); i++) {
        System.out.println(i + ". " + poliAnak.get(i));
      }

      System.out.println();
      System.out.print("Pilih Dokter: ");
      int pilihDokter = inputan.nextInt();
      System.out.print("Berikan Keterangan Dokter: ");
      String keteranganDokter = inputan.nextLine();
      String dummyDua = inputan.nextLine();

      System.out.println("");
      System.out.print("Masukkan Biaya Pendaftaran: ");
      int biayaPendaftaran = inputan.nextInt();
      System.out.print("Masukkan Biaya Obat: ");
      int biayaObat = inputan.nextInt();
      System.out.print("Masukkan Biaya Vitamin: ");
      int biayaVitamin = inputan.nextInt();
      System.out.print("Masukkan Biaya Pendaftaran: ");
      int biayaDokter = inputan.nextInt();
      System.out.println();
      System.out.println("------------------o0o--------------------");
      System.out.println("========================================");
      System.out.println();

      int totalBiaya = biayaPendaftaran + biayaObat + biayaVitamin + biayaDokter;

      System.out.println("Poli: " + pilihanPoli);
      System.out.println("Dokter: " + pilihDokter);
      System.out.println("Keterangan: " + keteranganDokter);
      System.out.println("Total Biaya yang di Bayar Pasien: " + totalBiaya);

    } else if (pilihanPoli == 3) {
      for (int i = 1; i < poliUmum.size(); i++) {
        System.out.println(i + ". " + poliUmum.get(i));
      }

      System.out.println();
      System.out.print("Pilih Dokter: ");
      int pilihDokter = inputan.nextInt();
      System.out.print("Berikan Keterangan Dokter: ");
      String keteranganDokter = inputan.nextLine();
      String dummyTiga = inputan.nextLine();

      System.out.println("");
      System.out.print("Masukkan Biaya Pendaftaran: ");
      int biayaPendaftaran = inputan.nextInt();
      System.out.print("Masukkan Biaya Obat: ");
      int biayaObat = inputan.nextInt();
      System.out.print("Masukkan Biaya Vitamin: ");
      int biayaVitamin = inputan.nextInt();
      System.out.print("Masukkan Biaya Pendaftaran: ");
      int biayaDokter = inputan.nextInt();
      System.out.println();
      System.out.println("------------------o0o--------------------");
      System.out.println("========================================");
      System.out.println();

      int totalBiaya = biayaPendaftaran + biayaObat + biayaVitamin + biayaDokter;

      System.out.println("Poli: " + pilihanPoli);
      System.out.println("Dokter: " + pilihDokter);
      System.out.println("Keterangan: " + keteranganDokter);
      System.out.println("Total Biaya yang di Bayar Pasien: " + totalBiaya);
    }
      System.out.println();
    System.out.println("Salam Sehat " + kasir + " dari Rumah Sakit Waras");
  }
}