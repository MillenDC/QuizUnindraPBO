package v2;

public class Sewa {
  private String jenisSewa;
  private String jenisMenuSewa;
  private int hargaSewa;
  private int jamSewa;

  public void Sewa(String jenisSewa, String jenisMenuSewa, int hargaSewa, int jamSewa) {
    this.jenisSewa = jenisSewa;
    this.jenisMenuSewa = jenisMenuSewa;
    this.hargaSewa = hargaSewa;
    this.jamSewa = jamSewa;

    if (jenisSewa.equals("Rias Wajah")) {
      jenisSewa = "Rias Wajah";

      if (jenisMenuSewa.equals("Rias Wajah Biasa")) {
        jenisMenuSewa = "Rias Wajah Biasa";
        hargaSewa = 100000;
      } else if (jenisMenuSewa.equals("Rias Wajah (Make Up Artis)")) {
        jenisMenuSewa = "Rias Wajah (Make Up Artis)";
        hargaSewa = 250000;
      }
    } else if (jenisSewa.equals("Baju Pengantin")) {
      jenisSewa = "Baju Pengantin";

      if (jenisMenuSewa.equals("Baju Pengantin Adat")) {
        jenisMenuSewa = "Baju Pengantin Adat";
        hargaSewa = 150000;
      } else if (jenisMenuSewa.equals("Baju Pengantin Internasional")) {
        jenisMenuSewa = "Baju Pengantin Internasional";
        hargaSewa = 350000;
      }
    } else if (jenisSewa.equals("Akesoris")) {
      jenisSewa = "Akesoris";

      if (jenisMenuSewa.equals("Aksesoris Anak")) {
        jenisMenuSewa = "Aksesoris Anak";
        hargaSewa = 20000;
      } else if (jenisMenuSewa.equals("Aksesoris Dewasa")) {
        jenisMenuSewa = "Aksesoris Dewasa";
        hargaSewa = 50000;
      }
    }
  }

  public String getJenisSewa() {
    return jenisSewa;
  }

  public String getJenisMenuSewa() {
    return jenisMenuSewa;
  }

  public int getHargaSewa() {
    return hargaSewa;
  }

  public int getJamSewa() {
    return jamSewa;
  }

  public int totalHargaSewa() {
    return hargaSewa * jamSewa;
  }
}