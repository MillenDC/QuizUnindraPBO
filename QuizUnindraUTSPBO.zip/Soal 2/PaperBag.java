package v3;

public class PaperBag {
  private String ukuranPaperBag;
  private int biayaPeminjaman;
  private int bunga;
  private int kewajibanBulanan;
  private int totalPeminjamanPaperBag;

  public void Perawatan(String ukuranPaperBag, int biayaPeminjaman, int bunga, int kewajibanBulanan, int totalPeminjamanPaperBag) {
    this.ukuranPaperBag = ukuranPaperBag;
    this.biayaPeminjaman = biayaPeminjaman;
    this.bunga = bunga;
    this.kewajibanBulanan = kewajibanBulanan;
    this.totalPeminjamanPaperBag = totalPeminjamanPaperBag;
  }

  public String getUkuranPaperBag() {
    return ukuranPaperBag;
  }

  public int getBiayaPeminjaman() {
    return biayaPeminjaman;
  }

  public int getBunga() {
    return bunga;
  }

  public int getKewajibanBulanan() {
    return kewajibanBulanan;
  }

  public int totalPeminjamanPaperBag() {
    return biayaPeminjaman + kewajibanBulanan;
  }
}