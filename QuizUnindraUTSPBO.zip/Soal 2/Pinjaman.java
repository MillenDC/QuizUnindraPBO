package v3;

import java.util.ArrayList;
import java.util.Scanner;

public class Pinjaman {
  public static void main(String[] args) {
    Scanner inputan = new Scanner(System.in);

    Karung karung = new Karung();
    PaperBag paperBag = new PaperBag();

    String namaPeminjam;
    int noKtp;

    ArrayList<String> menu = new ArrayList<String>();
    menu.add("");
    menu.add("Paket Karung");
    menu.add("Paket Paper Bag");

    ArrayList<String> ukuranKarungdanPaperBag = new ArrayList<String>();
    ukuranKarungdanPaperBag.add("");
    ukuranKarungdanPaperBag.add("XL");
    ukuranKarungdanPaperBag.add("L");
    ukuranKarungdanPaperBag.add("M");

    System.out.println("--- WELCOME TO THE SOLUTION OF MONEY ---");
    System.out.println("========================================");
    System.out.println();

    System.out.println("Silahkan Pilih Paket Peminjaman: ");
    System.out.println("========================================");
    System.out.println();

    for (int i = 1; i < menu.size(); i++) {
      System.out.println(i + ". " + menu.get(i));
    }

    System.out.println();
    System.out.print("Pilihan Menu: ");
    int pilihanMenu = inputan.nextInt();
    System.out.println("------------------<*>-------------------");
    System.out.println();
    
    System.out.println("Silahkan Masukkan Data Anda ");
    System.out.println("------------------<*>-------------------");
    System.out.println();

    System.out.print("Masukkan Nama Peminjam: ");
    namaPeminjam = inputan.nextLine();
    String dummySatu = inputan.nextLine();
    System.out.print("Masukkan No. KTP Peminjam: ");
    noKtp = inputan.nextInt();

    if (namaPeminjam.equals("PeminjamSatu") || noKtp == 123) {
      if (pilihanMenu == 1) {
        int biayaPeminjaman;
        int bunga;

        System.out.println();
        System.out.println("========================================");
        System.out.println("Pilih Ukuran Karung");
        System.out.println("========================================");
        System.out.println();

        for (int i = 1; i < ukuranKarungdanPaperBag.size(); i++) {
          System.out.println(i + ". " + ukuranKarungdanPaperBag.get(i));
        }

        System.out.println();
        System.out.print("Masukkan Pilihan: ");
        int pilihanUkuranKarung = inputan.nextInt();
        String dummyDua = inputan.nextLine();
        System.out.print("Berapa Lama Pinjam (bulan): ");
        int lamaPeminjamanKarung = inputan.nextInt();
        System.out.println();

        if (pilihanUkuranKarung == 1) {
          biayaPeminjaman = 100000000;
          bunga = biayaPeminjaman / 1000 * 25;
          System.out.println("Anda Memilih Paket " + ukuranKarungdanPaperBag.get(1));
          System.out.println("Dengan Pinjam: Rp. " + biayaPeminjaman);
          System.out.println("Dengan bunga: Rp. " + bunga);
          
          int kewajibanBulanan = bunga * lamaPeminjamanKarung / 2;
          int totalPeminjamanKarung = biayaPeminjaman + kewajibanBulanan;
          
          System.out.println();
          System.out.println("========================================");
          System.out.println("------ Total Kewajiban Pinjaman -------");
          System.out.println();

          System.out.println("Nama Peminjam: " + namaPeminjam);
          System.out.println("Kewajiban Bulanan: Rp. " + kewajibanBulanan);
          System.out.println();
          System.out.println("Total Pinjaman: Rp. " + totalPeminjamanKarung);
          System.out.println();

          karung.Karung(ukuranKarungdanPaperBag.get(1), biayaPeminjaman, karung.getBunga(), kewajibanBulanan, totalPeminjamanKarung);
        } else if (pilihanUkuranKarung == 2) {
          biayaPeminjaman = 75000000;
          bunga = biayaPeminjaman / 1000 * 25;
          System.out.println("Anda Memilih Paket " + ukuranKarungdanPaperBag.get(2));
          System.out.println("Dengan Pinjam: Rp. " + biayaPeminjaman);
          System.out.println("Dengan bunga: Rp. " + bunga);
          
          int kewajibanBulanan = bunga * lamaPeminjamanKarung / 2;
          int totalPeminjamanKarung = biayaPeminjaman + kewajibanBulanan;
          
          System.out.println();
          System.out.println("========================================");
          System.out.println("------ Total Kewajiban Pinjaman -------");
          System.out.println();

          System.out.println("Nama Peminjam: " + namaPeminjam);
          System.out.println("Kewajiban Bulanan: Rp. " + kewajibanBulanan);
          System.out.println();
          System.out.println("Total Pinjaman: Rp. " + totalPeminjamanKarung);
          System.out.println();

          karung.Karung(ukuranKarungdanPaperBag.get(2), biayaPeminjaman, karung.getBunga(), kewajibanBulanan, totalPeminjamanKarung);
        } else if (pilihanUkuranKarung == 3) {
          biayaPeminjaman = 50000000;
          bunga = biayaPeminjaman / 1000 * 25;
          System.out.println("Anda Memilih Paket " + ukuranKarungdanPaperBag.get(3));
          System.out.println("Dengan Pinjam: Rp. " + biayaPeminjaman);
          System.out.println("Dengan bunga: Rp. " + bunga);
          
          int kewajibanBulanan = bunga * lamaPeminjamanKarung / 2;
          int totalPeminjamanKarung = biayaPeminjaman + kewajibanBulanan;
          
          System.out.println();
          System.out.println("========================================");
          System.out.println("------ Total Kewajiban Pinjaman -------");
          System.out.println();

          System.out.println("Nama Peminjam: " + namaPeminjam);
          System.out.println("Kewajiban Bulanan: Rp. " + kewajibanBulanan);
          System.out.println();
          System.out.println("Total Pinjaman: Rp. " + totalPeminjamanKarung);
          System.out.println();

          karung.Karung(ukuranKarungdanPaperBag.get(3), biayaPeminjaman, karung.getBunga(), kewajibanBulanan, totalPeminjamanKarung);
        }
      } else if (pilihanMenu == 2) {
        int biayaPeminjaman;
        int bunga;

        System.out.println();
        System.out.println("========================================");
        System.out.println("Pilih Ukuran Paper Bag");
        System.out.println("========================================");
        System.out.println();

        for (int i = 1; i < ukuranKarungdanPaperBag.size(); i++) {
          System.out.println(i + ". " + ukuranKarungdanPaperBag.get(i));
        }

        System.out.println();
        System.out.print("Masukkan Pilihan: ");
        int pilihanUkuranPaperBag = inputan.nextInt();
        String dummyDua = inputan.nextLine();
        System.out.print("Berapa Lama Pinjam (bulan): ");
        int lamaPeminjamanPaperBag = inputan.nextInt();
        System.out.println();

        if (pilihanUkuranPaperBag == 1) {
          biayaPeminjaman = 30000000;
          bunga = biayaPeminjaman / 1000 * 25;
          System.out.println("Anda Memilih Paket " + ukuranKarungdanPaperBag.get(1));
          System.out.println("Dengan Pinjam: Rp. " + biayaPeminjaman);
          System.out.println("Dengan bunga: Rp. " + bunga);
          
          int kewajibanBulanan = bunga * lamaPeminjamanPaperBag / 2;
          int totalPeminjamanPaperBag = biayaPeminjaman + kewajibanBulanan;

          System.out.println();
          System.out.println("========================================");
          System.out.println("------ Total Kewajiban Pinjaman -------");
          System.out.println();

          System.out.println("Nama Peminjam: " + namaPeminjam);
          System.out.println("Kewajiban Bulanan: Rp. " + kewajibanBulanan);
          System.out.println();
          System.out.println("Total Pinjaman: Rp. " + totalPeminjamanPaperBag);
          System.out.println();
          
          paperBag.PaperBag(ukuranKarungdanPaperBag.get(1), biayaPeminjaman, paperBag.getBunga(), kewajibanBulanan, totalPeminjamanPaperBag);
        } else if (pilihanUkuranPaperBag == 2) {
          biayaPeminjaman = 20000000;
          bunga = biayaPeminjaman / 1000 * 25;
          System.out.println("Anda Memilih Paket " + ukuranKarungdanPaperBag.get(2));
          System.out.println("Dengan Pinjam: Rp. " + biayaPeminjaman);
          System.out.println("Dengan bunga: Rp. " + bunga);

          int kewajibanBulanan = bunga * lamaPeminjamanPaperBag / 2;
          int totalPeminjamanPaperBag = biayaPeminjaman + kewajibanBulanan;

          System.out.println();
          System.out.println("========================================");
          System.out.println("------ Total Kewajiban Pinjaman -------");
          System.out.println();

          System.out.println("Nama Peminjam: " + namaPeminjam);
          System.out.println("Kewajiban Bulanan: Rp. " + kewajibanBulanan);
          System.out.println();
          System.out.println("Total Pinjaman: Rp. " + totalPeminjamanPaperBag);
          System.out.println();
          
          paperBag.PaperBag(ukuranKarungdanPaperBag.get(2), biayaPeminjaman, paperBag.getBunga(), kewajibanBulanan, totalPeminjamanPaperBag);
        } else if (pilihanUkuranPaperBag == 3) {
          biayaPeminjaman = 10000000;
          bunga = biayaPeminjaman / 1000 * 25;
          System.out.println("Anda Memilih Paket " + ukuranKarungdanPaperBag.get(3));
          System.out.println("Dengan Pinjam: Rp. " + biayaPeminjaman);
          System.out.println("Dengan bunga: Rp. " + bunga);
          
          int kewajibanBulanan = bunga * lamaPeminjamanPaperBag / 2;
          int totalPeminjamanPaperBag = biayaPeminjaman + kewajibanBulanan;

          System.out.println();
          System.out.println("========================================");
          System.out.println("------ Total Kewajiban Pinjaman -------");
          System.out.println();

          System.out.println("Nama Peminjam: " + namaPeminjam);
          System.out.println("Kewajiban Bulanan: Rp. " + kewajibanBulanan);
          System.out.println();
          System.out.println("Total Pinjaman: Rp. " + totalPeminjamanPaperBag);
          System.out.println();
          
          paperBag.PaperBag(ukuranKarungdanPaperBag.get(3), biayaPeminjaman, paperBag.getBunga(), kewajibanBulanan, totalPeminjamanPaperBag);
        }
      }
      System.out.println("Terimakasih sudah meminjam di THE SOLUTION OF MONEY");
      System.out.println("Pusing dengan Keuangan? Kami Solusinya (*_*)");
    } else {
      System.out.println("Silahkan Daftar Menjadi Peminjam Terlebih Dahulu");
    }
  }
}